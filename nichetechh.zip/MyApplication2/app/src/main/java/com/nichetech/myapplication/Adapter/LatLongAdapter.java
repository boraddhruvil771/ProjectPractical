package com.nichetech.myapplication.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.nichetech.myapplication.POJO.LatLong;
import com.nichetech.myapplication.R;
import com.nichetech.myapplication.databinding.OrderListItemBinding;

import java.util.List;

public class LatLongAdapter extends RecyclerView.Adapter<LatLongAdapter.MyViewHolder> {

    List<LatLong> mlist;
    Context context;

    public LatLongAdapter(List<LatLong> mlist, Context context) {
        this.mlist = mlist;
        this.context = context;
    }

    public void updatelist(List<LatLong> temp) {
        this.mlist = temp;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public LatLongAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        OrderListItemBinding itemView = DataBindingUtil.inflate(layoutInflater, R.layout.order_list_item, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull LatLongAdapter.MyViewHolder holder, int position) {

        LatLong ll = mlist.get(position);

        holder.itemView.txtLat.setText(""+ll.getLatitude());
        holder.itemView.txtLong.setText(""+ll.getLongitude());

    }

    @Override
    public int getItemCount() {
        return (mlist == null) ? 0 : mlist.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        OrderListItemBinding itemView;

        public MyViewHolder(@NonNull OrderListItemBinding itemView) {
            super(itemView.getRoot());
            this.itemView=itemView;
        }
    }
}
